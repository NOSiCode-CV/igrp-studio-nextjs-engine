'use server';

import { Application } from '@/features/applications/types';
import { callApi } from '@/lib/api-client';

export async function getApplicationByCode(code: string) {
  return callApi<Application[]>(`/api/applications?code=${code}`, {
    method: 'GET',
  });
}
