'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from '@/components/ui/sidebar'
import { NavUser } from '@/components/nav-user'
import { AppSwitcher } from '@/components/app-switcher'
import { CommandSearch } from '@/components/command-search'
import { DEFAULT_IGRP_APPS, DEFAULT_IGRP_APPS_DATA } from '@/config/apps'
import { DEFAULT_IGRP_FOOTER_MENU } from '@/config/menus'
import { IGRPMenus } from './app-menus'
import { useApplicationByCode } from '@/features/applications/hooks/use-applications'

// TDOD: messages

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const appCode = process.env.NEXT_PUBLIC_IGRP_APP_CODE || ''  
  const pathname = usePathname()
  const { data: application, isLoading, error } = useApplicationByCode(appCode)

  if (isLoading && !error) return <></>
  if (error) throw error    
  
  const app = application?.[0] || DEFAULT_IGRP_APPS_DATA
  console.log({ appCode })
  console.log({ app })

  return (
    <Sidebar collapsible='icon' {...props} bgClassName='bg-primary text-primary-foreground'>
      <SidebarHeader className='gap-6'>
        <AppSwitcher apps={DEFAULT_IGRP_APPS} />
        <SidebarGroup className='py-0 group-data-[collapsible=icon]:hidden'>
          <SidebarGroupContent>
            <CommandSearch />
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarHeader>

      <SidebarContent className='mt-4'>
        <SidebarGroup className="gap-2">
          <SidebarGroupContent>
            <IGRPMenus appId={app.id} />
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <div className='space-y-4'>
          {/* <SidebarGroupContent>
            <SidebarMenu className='gap-2'>
              {DEFAULT_IGRP_FOOTER_MENU.map(({ title, url, icon: Icon }) => {
                const isExternal = url.startsWith('http')
                const isActive = pathname === url

                return (
                  <SidebarMenuItem key={title}>
                    <SidebarMenuButton
                      asChild
                      tooltip={title}
                      isActive={isActive}
                    >
                      {isExternal ? (
                        <a href={url} target='_blank' rel='noopener noreferrer'>
                          {Icon && <Icon />}
                          <span className='flex items-center gap-1'>{title}</span>
                        </a>
                      ) : (
                        <Link href={url}>
                          {Icon && <Icon />}
                          <span>{title}</span>
                        </Link>
                      )}
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent> */}

          <NavUser />
        </div>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  )
}