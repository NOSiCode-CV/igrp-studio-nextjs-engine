'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { useTheme } from 'next-themes'
import { IGRPAppsProps } from '@/config/apps'

export function AppSwitcher({ apps }: { apps: IGRPAppsProps }) {
  const [mounted, setMounted] = useState(false)
  const { theme, resolvedTheme } = useTheme()

  useEffect(() => {
    setMounted(true);
  }, []);

  const activeApp = apps[0]

  if (!activeApp) return null

  const imgSrc = mounted
    ? (theme === 'dark' || resolvedTheme === 'dark' ? activeApp.logo.srcDark : activeApp.logo.src)
    : activeApp.logo.src;    

  return (
    <div className='flex items-center justify-center gap-3 p-2 group-data-[collapsible=icon]:gap-0 group-data-[collapsible=icon]:p-0'>
      {activeApp.logo.src && activeApp.logo.srcDark ? (
        <Image
          src={imgSrc}
          alt={activeApp.name}
          width={45}
          height={45}
          priority
        />
      ) :
        <div className='flex aspect-square size-8 justify-center rounded-lg'>
          <activeApp.icon className='size-4' />
        </div>
      }

      <div className='grid flex-1 text-left text-sm leading-tight'>
        <span className='truncate font-semibold'>
          {activeApp.name}
        </span>
        <span className='truncate text-xs'>{activeApp.description}</span>
      </div>
    </div>

  )
}
