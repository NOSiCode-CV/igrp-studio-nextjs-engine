"use client"

import {
  SidebarInset,
  SidebarProvider,
  IGRPHeader,
  IGRPSidebar,
  IGRPSidebarContent,
  IGRPSidebarFooter,
  IGRPSidebarHeader
} from '@igrp/igrp-framework-react-design-system'

import { Providers } from '@/components/ProgressBarProvider'
import { SidebarProps } from '@igrp/igrp-framework-react-design-system/types';

const user = {
  name: 'SISS',
  email: 'admin@siss',
  avatar: '',
}

export const AppConfig = {
  logo: {
    src: 'https://storage-api.nosi.cv/inss-gb-cms-dev/logo_b4781204ce.svg',
    alt: 'INSS Logo',
    width: 200,
    height: 80,
  },
  name: 'SISS',
  description: 'Sistema de Informação de Segurança Social',  
};

const MainNavItems: SidebarProps[] = [
  {
    name: 'Página Inicial',    
    href: process.env.NEXT_PUBLIC_APP_BASE_URL,
  },
  { 
    name: 'Caixa de Entrada', 
    href: '/inbox' 
  },
  { 
    name: 'Bibliotecas',     
    href: '/libraries' 
  },
];

const FooterNavItems: SidebarProps[] = [
  {
    name: 'Gestão de Acesso',
    href: '#',
    items: [
      {
        name: 'Gestão de Utilizadores',
        href: "#",
      },
      {
        name: 'Gestão de Departamentos',
        href: "#",
      },
    ],
  },
  {
    name: 'Gestão de Aplicações',
    href: "#",
  },
  {
    name: 'Configurações do Sistema',
    href: "#",
  },
  {
    name: 'Suporte',
    href: "#",
  },
];


export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <IGRPSidebar>
        <IGRPSidebarHeader {...AppConfig} />
        <IGRPSidebarContent
          items={MainNavItems}
          searchActive
        />
        <IGRPSidebarFooter
          items={FooterNavItems}
        />
      </IGRPSidebar>
      <Providers>
        <SidebarInset className="overflow-y-auto">
          <section>
            <IGRPHeader
              onLogout={() => console.log("Logout")}
              notifications={[]}
              user={user}
              bpmnActive
              notificationActive
            />
            <section className="p-4">
              {children}
            </section>
          </section>
        </SidebarInset>
      </Providers>
    </SidebarProvider>
  )
}