'use client'

import { Fragment, useMemo, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ChevronRightIcon } from 'lucide-react'
import { IGRPIcon } from '@igrp/igrp-framework-react-design-system'
import { 
  Collapsible, 
  CollapsibleContent, 
  CollapsibleTrigger 
} from '@/features/igrp/components/ui/collapsible'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/features/igrp/components/ui/dropdown-menu'
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from '@/features/igrp/components/ui/sidebar'
import { IGRP_DEFAULT_MENU } from '@/features/igrp/config/menus'
import { useMenusByApplication } from '@/features/menus/hooks/use-menus'
import type { IGRPMenuProps } from '@/features/menus/types'
import { isExternalUrl, normalizeUrl } from '@/lib/utils'

interface IGRPMenusProps {
  appId: number
}

export function IGRPMenus({ appId }: IGRPMenusProps) {
  const [menus, setMenus] = useState<IGRPMenuProps[]>(IGRP_DEFAULT_MENU)
  const pathname = usePathname()
  const { data, isLoading, error } = useMenusByApplication(appId)

  console.log({ menus })

  const topLevelMenus = useMemo(
    () => menus.filter((menu) => menu.parentId === null).sort((a, b) => a.position - b.position),
    [menus],
  )

  const childMap = useMemo(() => {
    const map = new Map<number, IGRPMenuProps[]>()

    menus.forEach((menu) => {
      if (menu.parentId !== null) {
        if (!map.has(menu.parentId)) {
          map.set(menu.parentId, [])
        }
        map.get(menu.parentId)?.push(menu)
      }
    })

    map.forEach((children) => children.sort((a, b) => a.position - b.position))

    return map
  }, [menus])

  const getChildren = (parentId: number): IGRPMenuProps[] => childMap.get(parentId) || []

  if (isLoading && !error) return null
  if (error) throw error
  if (data) setMenus(data)
  
  console.log({ data })

  return (
    <>
      {!data && <div className='py-4 text-sm text-primary-foreground underline underline-offset-4 flex-wrap'>No menus found</div>}
      <SidebarMenu className='gap-2'>
        {topLevelMenus.map((menu) => (
          <MenuItemWithSubmenus
            key={`menu-${menu.id}-${menu.name}`}
            menu={menu}
            pathname={pathname}
            childMenus={getChildren(menu.id)}
          />
        ))}
      </SidebarMenu>
    </>
  )
}

interface MenuItemWithSubmenusProps {
  menu: IGRPMenuProps
  pathname: string
  childMenus: IGRPMenuProps[]
}

function MenuItemWithSubmenus({ menu, pathname, childMenus }: MenuItemWithSubmenusProps) {
  const { id, name, url, icon } = menu
  const isActive = pathname === url
  const hasChildren = childMenus.length > 0
  const isExternal = isExternalUrl(url)
  const urlNormalize = normalizeUrl(url)

  if (!hasChildren) {
    return (
      <SidebarMenuItem>
        <SidebarMenuButton
          asChild
          tooltip={name}
          isActive={isActive}
        >
          {isExternal ? (
            <a
              href={urlNormalize || ''}
              target='_blank'
              rel='noopener noreferrer'
            >
              {icon && <IGRPIcon name={icon} />}
              <span>{name}</span>
            </a>
          ) : (
            <Link href={url || ''}>
              {icon && <IGRPIcon name={icon} />}

              <span>{name}</span>
            </Link>
          )}
        </SidebarMenuButton>
      </SidebarMenuItem>
    )
  }

  return (
    <Fragment>
      <SidebarMenuItem className='group'>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <SidebarMenuButton
              tooltip={name}
              className='w-full cursor-pointer group-data-[collapsible=""]:hidden'
            >
              {icon && <IGRPIcon name={icon} />}
            </SidebarMenuButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent side='right' align='start'>
            {childMenus.map((subMenu, idx) => (
              <SubMenuItem
                key={`dropdown-${subMenu.name}-${idx}`}
                menu={subMenu}
                variant='dropdown'
              />
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarMenuItem>

      <SidebarMenuItem>
        <Collapsible className='w-full group'>
          <CollapsibleTrigger
            className='flex w-full group-data-[collapsible=icon]:hidden'
            asChild
          >
            <SidebarMenuButton
              tooltip={name}
              className='w-full cursor-pointer'
            >
              {icon && <IGRPIcon name={icon} />}
              <span>{name}</span>
              <ChevronRightIcon
                className='ml-auto transition-transform duration-200 group-data-[state=open]:rotate-90'
                strokeWidth={2}
              />
            </SidebarMenuButton>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <SidebarMenuSub className='gap-2'>
              {childMenus.map((subMenu, idx) => (
                <SubMenuItem
                  key={`collapse-${id}-${subMenu.name}-${idx}`}
                  menu={subMenu}
                  variant='collapsible'
                />
              ))}
            </SidebarMenuSub>
          </CollapsibleContent>
        </Collapsible>
      </SidebarMenuItem>
    </Fragment>
  )
}

interface SubMenuItemProps {
  menu: IGRPMenuProps
  variant: 'dropdown' | 'collapsible'
}

function SubMenuItem({ menu, variant }: SubMenuItemProps) {
  const { name, url, icon } = menu
  const isExternal = isExternalUrl(url)
  const urlNormalize = normalizeUrl(url)

  const content = (
    <>
      {icon && variant === 'dropdown' && (
        <IGRPIcon name={icon} />
      )}
      <span>{name}</span>
    </>
  )

  if (variant === 'dropdown') {
    return (
      <DropdownMenuItem
        asChild
        onSelect={(e) => e.preventDefault()}
        className='hover:bg-primary hover:text-primary-foreground cursor-pointer px-2 py-2.5'
      >
        {isExternal ? (
          <a
            href={urlNormalize || ''}
            target='_blank'
            rel='noopener noreferrer'
            className='w-full'
          >
            {content}
          </a>
        ) : (
          <Link href={url || ''} className='w-full'>
            {content}
          </Link>
        )}
      </DropdownMenuItem>
    )
  }

  return (
    <SidebarMenuSubItem>
      {isExternal ? (
        <SidebarMenuSubButton
          className="text-primary-foreground"
          href={urlNormalize || ""}
          target="_blank"
          rel="noopener noreferrer"
        >
          <span>{name}</span>
        </SidebarMenuSubButton>
      ) : (
        <Link href={url || ""}>
          <SidebarMenuSubButton asChild className="text-primary-foreground">
            <span>{name}</span>
          </SidebarMenuSubButton>
        </Link>
      )}
    </SidebarMenuSubItem>
  )
}
