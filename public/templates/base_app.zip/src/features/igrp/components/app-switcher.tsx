'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { useTheme } from 'next-themes'
import { DEFAULT_IGRP_APPS, DEFAULT_IGRP_APPS_DATA, IGRPAppsProps } from '@/features/igrp/config/apps'
import { Application } from '@/features/applications/types'

// TODO: review this, to get the configuration from /api by id, or add image dark and ligth to the create app adicionar icon to create app

export function AppSwitcher({ app }: { app?: Application }) {
  const [mounted, setMounted] = useState(false)
  const { theme, resolvedTheme } = useTheme()

  useEffect(() => {
    setMounted(true);
  }, []);

  const currentApp = app ?? DEFAULT_IGRP_APPS_DATA

  const imgSrc = mounted
    ? (theme === 'dark' || resolvedTheme === 'dark' ? DEFAULT_IGRP_APPS[0].logo.srcDark : currentApp.picture)
    : currentApp.picture;

  return (
    <div className='flex items-center justify-center gap-3 p-2 group-data-[collapsible=icon]:gap-0 group-data-[collapsible=icon]:p-0'>
      <Image
        src={imgSrc || DEFAULT_IGRP_APPS[0].logo.src}
        alt={currentApp.name}
        width={45}
        height={45}
        className='h-auto w-auto'
        priority
      />

      <div className='grid flex-1 text-left text-sm leading-tight'>
        <span className='truncate font-semibold'>
          {currentApp.name}
        </span>
        <span className='truncate text-xs'>{currentApp.description}</span>
      </div>
    </div>
  )
}
