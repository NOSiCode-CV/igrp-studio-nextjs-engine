import { Breadcrumbs } from './breadcrumbs';
import { LanguageSelector } from './language-selector';
import { ModeSwitcher } from './mode-switcher';
import { Notifications } from './notifications';
import { Separator } from './ui/separator';
import { SidebarTrigger } from './ui/sidebar';

interface HeaderProps {
  showBreadcrumbs?: boolean;
}
export function Header({ showBreadcrumbs }: HeaderProps) {
  return (
    <header className="bg-background sticky inset-x-0 top-0 isolate z-10 flex shrink-0 items-center gap-2 border-b">
      <div className="flex items-center gap-2 h-12 w-full pl-2 pr-4">
        <SidebarTrigger className="size-5" />
        {showBreadcrumbs && (
          <>
            <Separator orientation="vertical" className="mr-2 data-[orientation=vertical]:h-4" />
            <div className="py-2">
              <Breadcrumbs />
            </div>
          </>
        )}
        <div className="ml-auto flex items-center gap-2">
          <Notifications />
          <ModeSwitcher />
          <LanguageSelector />
        </div>
      </div>
    </header>
  );
}
