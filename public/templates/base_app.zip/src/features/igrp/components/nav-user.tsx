'use client'

import { useState } from 'react'
import { ChevronsUpDown } from 'lucide-react'
import { DEFAULT_IGRP_USER } from '@/features/igrp/config/user'
import { SidebarMenuButton } from '@/features/igrp/components/ui/sidebar'
import { UserAvatar } from '@/features/igrp/components/user-avatar'
import { useCurrentUser } from '@/features/users/hooks/use-users'
import { UserProps } from '@/features/users/types'
import { getInitials } from '@/lib/utils'

export function NavUser() {
  const [currentUser, setCurrentUser] = useState<UserProps>(DEFAULT_IGRP_USER)
  const { data: user, isLoading, error } = useCurrentUser()
 
  if (isLoading && !error) return <></>
  if (error) throw error
  if (user) setCurrentUser(user)  

  console.log({ currentUser })

  return (
    <SidebarMenuButton
      className='group data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground group-data-[collapsible=icon]:pl-0! py-2!'
      tooltip={currentUser.igrpUsername}
      size='lg'
    >
      <UserAvatar
        image={currentUser.image}
        alt={currentUser.igrpUsername}
        fallbackContent={getInitials(currentUser.igrpUsername)}
        fallbackClass='text-foreground'
        className='shadow-md'
      />
      <div className='grid flex-1 text-left text-sm leading-tight'>
        <span className='truncate font-semibold'>{currentUser.igrpUsername || 'N/A'}</span>
        <span className='truncate text-xs'>{currentUser.email}</span>
      </div>
      <ChevronsUpDown className='ml-auto size-3.5' strokeWidth={2} />
    </SidebarMenuButton>
  )
}
