import { useQuery } from '@tanstack/react-query'
import { getApplicationByCode } from '@/actions/(igrp)/applications'
import { Application } from '@/features/applications/types'

export const useApplicationByCode = (code: string) => {
  return useQuery<Application[]>({
    queryKey: ['application', code],
    queryFn: () => getApplicationByCode(code),
  })
}