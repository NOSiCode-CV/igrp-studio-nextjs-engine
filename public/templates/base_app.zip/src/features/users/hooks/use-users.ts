import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { 
  getUser, 
  getRolesFromUser, 
} from '@/app/actions/(igrp)/user'
import type { DepartmentProps, InviteUserProps, UserProps, UserPropsImage } from "@/features/users/types"
import { OptionsProps } from "@/types/globals"

export const useCurrentUser = () => {
  return useQuery<UserProps | null>({
    queryKey: ["current-user"],
    queryFn: async () => getUser(),
  })
}

export function useRolesFromUser(userName?: string) {
  return useQuery<string[]>({
    queryKey: ["user-roles-from", userName],
    queryFn: () => getRolesFromUser(userName),
    enabled: !!userName,
  })
}