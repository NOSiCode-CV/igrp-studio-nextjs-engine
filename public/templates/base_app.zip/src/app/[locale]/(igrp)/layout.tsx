'use client'

import { useEffect } from 'react'
import { redirect } from 'next/navigation'
import { useSession } from 'next-auth/react'
import  Cookies from 'js-cookie'
import { IGRPToaster } from '@igrp/igrp-framework-react-design-system'
import { MainLayout } from '@/components/main-layout'

export default function LocaleLayout({ 
  children, 
  }: Readonly<{ 
    children: React.ReactNode,
  }>) {

  const { data: session, status } = useSession()
  const defaultOpen = Cookies.get('sidebar_state') === 'true'  

  useEffect(() => {
    if (
      process.env.NODE_ENV === "production" &&
      (status === 'unauthenticated' ||
      (status === 'authenticated' && session?.error === 'RefreshAccessTokenError'))) {
      redirect('/logout');
    }
  }, [session, status]);

  return (
    <MainLayout sidebarOpen={defaultOpen}>
      {children}
      <IGRPToaster richColors />
    </MainLayout>
  );
}
